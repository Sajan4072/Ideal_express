"use strict";
(() => {
var exports = {};
exports.id = 423;
exports.ids = [423];
exports.modules = {

/***/ 462:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_service),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: ./data/prohibited.data.ts
const prohibitedData = [
    {
        title: "Corrosives",
        icon: "/icon/prohibited/corrosive.png"
    },
    {
        title: "Gases",
        icon: "/icon/prohibited/gas.png"
    },
    {
        title: "Flammable Liquids",
        icon: "/icon/prohibited/kerosene.png"
    },
    {
        title: "Oxidising Material",
        icon: "/icon/prohibited/toxic.png"
    },
    {
        title: "Organic Preoxides",
        icon: "/icon/prohibited/organic-toxic.png"
    },
    {
        title: "Toxic Substances",
        icon: "/icon/prohibited/flask.png"
    },
    {
        title: "Radioactive Materials",
        icon: "/icon/prohibited/nuclear-power.png"
    },
    {
        title: "Infectious Substances",
        icon: "/icon/prohibited/coronavirus.png"
    },
    {
        title: "Expolsives",
        icon: "/icon/prohibited/bomb.png"
    },
    {
        title: "Miscellaneous including dry ice and petrol engines",
        icon: "/icon/prohibited/garbage.png"
    },
    {
        title: "Flammable Solids",
        icon: "/icon/prohibited/flammable.png"
    },
    {
        title: "Magnetised Material",
        icon: "/icon/prohibited/magnet.png"
    }, 
];

;// CONCATENATED MODULE: ./data/service.data.ts
const serviceData = [
    {
        theme: "International",
        options: [
            {
                title: "Air Freight-Export Cargo",
                description: "Reliable and hassle free. Broad range of delivery speeds and service options.",
                icon: "/icon/service/global-shipping.png"
            },
            {
                title: "Import Cargo & Customs",
                description: "Reliable and hassle free. Broad range of delivery speeds and service options.",
                icon: "/icon/service/cargo-boat.png"
            }, 
        ]
    },
    {
        theme: "Domestic",
        options: [
            {
                title: "E-commerce Solutions",
                description: "Reliable and hassle free. Broad range of delivery speeds and service options.",
                icon: "/icon/service/ecommerce.png"
            },
            {
                title: "Domestic Courier",
                description: "Reliable and hassle free. Broad range of delivery speeds and service options.",
                icon: "/icon/service/domestic.png"
            }, 
        ]
    }, 
];

;// CONCATENATED MODULE: ./pages/service.tsx





const service = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(Service, {});
};
/* harmony default export */ const pages_service = (service);
const Service = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "shadow-sm overflow-hidden min-h-[50vh] z-0 bg-center bg-cover",
                style: {
                    backgroundImage: "url(/wallpaper/walpaper.jpg)"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "text-white pt-48 pb-28 h-[10h] px-2 md:px-24 bg-black bg-opacity-60 w-full flex justify-center items-center ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "grid grid-cols-2 items-start w-full",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "justify-self-start",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/",
                                                children: "Home"
                                            })
                                        }),
                                        " ",
                                        ">",
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-orange-500",
                                            children: "service"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-4xl font-bold",
                                    children: "Services"
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Section2, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(SectionProhibited, {})
        ]
    });
};
const Section2 = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-slate-100",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "py-5 container mx-auto px-5",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "text-center my-10",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-3xl font-bold",
                        children: "Our logistic service"
                    })
                }),
                serviceData.map((current, index)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "my-5 py-2 px-5 border rounded-sm border-transparent bg-orange-500 border-l-orange-700 border-l-8",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "capitalize text-white text-xl font-bold ",
                                    children: current.theme
                                })
                            }, index),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "grid grid-cols-2 gap-5 my-3",
                                children: current.options.map((data, index2)=>{
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "border bg-white rounded-md shadow-md p-8 ",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex py-3 justify-center",
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: data.icon,
                                                        className: "h-28 w-32",
                                                        alt: ""
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "text-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "text-2xl font-bold",
                                                        children: data.title
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "text-base text-gray-500",
                                                        children: data.description
                                                    })
                                                ]
                                            })
                                        ]
                                    }, index2);
                                })
                            })
                        ]
                    });
                })
            ]
        })
    });
};
const SectionProhibited = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "py-10 bg-gray-50",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container mx-auto px-5",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "text-center w-2/3 mx-auto",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-3xl font-bold py-5",
                            children: "PROHIBITED ITEMS IN CARGO"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-gray-500 py-3 text-sm",
                            children: "The following restrictions apply to all services offered on our website. However, it is highly advisable to also check the policy of your chosen carrier as further restrictions may apply. We also recommend that you check with customs at the destination country that you wish to send to, as each country has different policies as to what will be accepted into the country. If you are in any doubt, please contact our customer services team."
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "grid grid-cols-6 gap-1",
                    children: prohibitedData.map((current, index)=>{
                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: " border rounded-md cursor-pointer hover:shadow-2xl bg-white p-2 ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex py-3 justify-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: "",
                                        src: current.icon,
                                        alt: current.title
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-center pt-4 pb-2 ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-xl font-extrabold text-red-600 font-poppin cursor-text",
                                        children: current.title
                                    })
                                })
                            ]
                        }, index);
                    })
                })
            ]
        })
    });
};
const getServerSideProps = async (context)=>{
    return {
        props: {
            title: "Service Page | Ideal Courier"
        }
    };
};


/***/ }),

/***/ 796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 14:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 20:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 52:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 422:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664], () => (__webpack_exec__(462)));
module.exports = __webpack_exports__;

})();