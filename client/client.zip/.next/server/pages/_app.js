"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 824:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: ./layouts/Footer.tsx

const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " bg-slate-200 font-roboto",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-slate p-5 mx-auto container ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-cols-1 md:grid-cols-12 gap-20",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: " md:col-span-6",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "w-full mt-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "my-2 uppercase font-roboto text-justify font-bold text-lg",
                                            children: "Courior pickup ,Delivery,online shopping Service ,logistic & supply chain ideal express"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-base font-work-sans text-gray-500",
                                            children: "We are ready to give solutions tailored to customer needs and requirements. To confirm elevated precision in our services, we have developed a complete infrastructure required to handle both national and international delivery of shipments. ."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "my-2",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/logo/logo.png",
                                        className: " w-[100%] md:w-[60%] hover:scale-105 cursor-pointer",
                                        alt: "logo"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: " md:col-span-6 ",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid grid-cols-2 my-5 font-poppin text-base",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: 'relative pb-2 uppercase text-base font-bold font-work-sans after:content[""] after:h-1 after:absolute after:bottom-0 after:left-0 after:w-[6.5rem] after:bg-orange-600 ',
                                                children: "Quick Links"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-col justify-between gap-4 mt-5",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: " hover:text-orange-600 font-bold ",
                                                        children: "Home"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: " hover:text-orange-600 font-bold ",
                                                        children: "Service"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: " hover:text-orange-600 font-bold ",
                                                        children: "Contctus"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: " hover:text-orange-600 font-bold ",
                                                        children: "Branch"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: 'relative pb-2 uppercase text-base font-bold font-work-sans after:content[""] after:h-1 after:absolute after:bottom-0 after:left-0 after:w-[6.5rem] after:bg-orange-600 ',
                                                children: "Get In Touch"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-col justify-between gap-4 mt-5",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Head Office: Gaushala Chowk, Battisputali Road (Along with NIC Asia Bank & Nearby Hotel Dwarika), Kathmandu, Nepal"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "+977-1-4578809, 4478678"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "info@idealcourier.com.np"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-[#c64300] text-white",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                        className: "text-transparent mt-2"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container px-5 mx-auto",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid grid-cols-1 md:grid-cols-3 py-2",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "md:justify-self-start text-sm justify-self-center items-center",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "inline-block",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "#",
                                                    className: "",
                                                    children: "Term and condition"
                                                }),
                                                "  ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "",
                                                    children: "|"
                                                }),
                                                "  ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: "",
                                                    href: "#",
                                                    children: "privacy policy"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: "text-center ",
                                            children: [
                                                "\xa9 ",
                                                new Date().getFullYear(),
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "",
                                                    children: "idealcourior.com.np"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "md:justify-self-center text-center text-sm justify-self-center items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "inline-block",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Develope by"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-center ",
                                            children: "jit bdr rana,sajan rai"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "md:justify-self-end justify-self-center items-center flex",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex flex-wrap gap-2 ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "facebok",
                                                href: "",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: "/social/facebook.png",
                                                    className: "w-8 h-8",
                                                    alt: ""
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "instagram",
                                                href: "",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: "/social/instagram.png",
                                                    className: "w-8 h-8",
                                                    alt: ""
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                title: "twitter",
                                                href: "",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: "/social/twitter.png",
                                                    className: "w-8 h-8",
                                                    alt: ""
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const layouts_Footer = (Footer);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: external "react-icons/ri"
const ri_namespaceObject = require("react-icons/ri");
;// CONCATENATED MODULE: external "react-icons/ai"
const ai_namespaceObject = require("react-icons/ai");
;// CONCATENATED MODULE: external "react-icons/md"
const md_namespaceObject = require("react-icons/md");
;// CONCATENATED MODULE: external "react-icons/fa"
const fa_namespaceObject = require("react-icons/fa");
;// CONCATENATED MODULE: external "react-icons/bi"
const bi_namespaceObject = require("react-icons/bi");
;// CONCATENATED MODULE: ./data/routing.data.tsx






const data = [
    {
        name: "Home",
        url: "/",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_namespaceObject.BiHome, {})
    },
    {
        name: "Service",
        url: "/service",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(ri_namespaceObject.RiCustomerService2Fill, {})
    },
    {
        name: "Contactus",
        url: "/contactus",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(ai_namespaceObject.AiOutlinePhone, {})
    },
    {
        name: "Aboutus",
        url: "/aboutus",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(ri_namespaceObject.RiUserLocationLine, {})
    },
    {
        name: "Network",
        url: "/network",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(fa_namespaceObject.FaGlobeAfrica, {})
    },
    {
        name: "Gallery",
        url: "/gallery",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(md_namespaceObject.MdPhotoLibrary, {})
    }, 
];


;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
;// CONCATENATED MODULE: ./layouts/Header.tsx





const Header = ()=>{
    const { 0: fixnav , 1: setFixnav  } = (0,external_react_.useState)(false);
    const { 0: nav , 1: setNav  } = (0,external_react_.useState)();
    const router = (0,router_namespaceObject.useRouter)();
    const handleScrollChange = ()=>{
        const position = window.pageYOffset;
        if (position > 100) {
            setFixnav(true);
        } else {
            setFixnav(false);
        }
    };
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", handleScrollChange, {
            passive: true
        });
        if (!sessionStorage.getItem("activeNav") || sessionStorage.getItem("activeNav") === "") {
            sessionStorage.setItem("activeNav", `0`);
        } else {
            setNav(parseInt(sessionStorage.getItem("activeNav")));
        }
        return ()=>{
            window.removeEventListener("scroll", handleScrollChange);
        };
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `py-2 font-roboto  bg-white ${fixnav ? "fixed shadow-md md:py-0 md:bg-white text-black z-50 animate-fadeInDown  " : "md:py-0 absolute md:bg-black text-white md:bg-opacity-30"} inset-x-0 border-b border-transparent`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "grid grid-cols-12 pt-1 px-2 md:px-5 container mx-auto",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-span-6 md:col-span-4 justify-self-start flex justify-items-center justify-start",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `my-1 ${fixnav ? "md:w-[70%]" : "md:w-[90%]"} w-[100%] cursor-pointer `,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/logo/logo.png",
                                className: "w-full",
                                alt: ""
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "col-span-6 md:col-span-8 justify-self-end flex justify-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "md:hidden justify-self-end mt-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/icon/list.png",
                                className: "h-8 w-8",
                                alt: "menu"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `${fixnav ? "" : "md:mt-6"} `,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: ` text-xs hidden  ${fixnav ? "hidden" : "md:flex"}  flex-row-reverse gap-x-6`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: "",
                                                className: "p-2.5 transition ease-in-out delay-150 hover:-translate-y-3 hover:scale-110 rounded-md hover:bg-orange-500 hover:text-white bg-white text-black text-sm font-bold",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fi fi-br-home"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ml-2 ",
                                                        children: "Branch Login"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-2 items-center ",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: "/icon/email.png",
                                                    className: "h-6 w-6 ",
                                                    alt: ""
                                                }),
                                                "info@idealcourier.com.np"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-2 items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: "/icon/viber.png",
                                                    className: "h-6 w-6 ",
                                                    alt: ""
                                                }),
                                                "+977-9851168433"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-2 items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: "/icon/whatsapp.png",
                                                    className: "h-6 w-6 ",
                                                    alt: ""
                                                }),
                                                "+977-9851168433"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `md:flex hidden ${fixnav ? "   items-center" : " items-end"} mt-1  flex justify-center    gap-x-11`,
                                    children: data.map((data, index)=>{
                                        return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: data.url,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "group cursor-pointer",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: `flex justify-center text-lg ${!fixnav ? "hidden" : "group-hover:text-orange-500"} ${router.pathname === data.url && "text-orange-500"} flex justify-center`,
                                                        children: data.icon
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: `pb-3 ${router.pathname === data.url && "active-nav"} group-hover:active-nav relative text-sm font-bold items-end before:hover:wiggle before:contents['']  before:absolute before:h-[0.155rem] before:bottom-0 before:w-[100%] before:hover:bg-orange-500 ${fixnav ? " mt-2" : "mt-8 "} cursor-pointer before:hover:transition before:hover:duration-[0.8s] before:hover:ease-ease  before:hover:delay-[0s] before:hover:animate-wiggle hover:text-orange-500`,
                                                        children: data.name
                                                    })
                                                ]
                                            })
                                        });
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const layouts_Header = (Header);

;// CONCATENATED MODULE: ./layouts/Mainlayout.tsx





function MainLayout({ children , title , metaImg , metaTitle , metaDescription , metaKeyword , metaTag  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "shortcut icon",
                        href: "/favicon.ico"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:image",
                        content: metaImg
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:title",
                        content: metaTitle
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:description",
                        content: metaDescription
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "fb:app_id",
                        content: "961541957962839"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: metaDescription
                    }),
                    metaKeyword && /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "keywords",
                        content: metaKeyword
                    }),
                    metaTag && /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "tags",
                        content: metaTag
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "author",
                        content: "idealcourier.com.np"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "stylesheet",
                        href: "https://cdn-uicons.flaticon.com/uicons-bold-rounded/css/uicons-bold-rounded.css"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "stylesheet",
                        href: "https://cdn-uicons.flaticon.com/uicons-regular-rounded/css/uicons-regular-rounded.css"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "stylesheet",
                        href: "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.0/css/font-awesome.min.css",
                        integrity: "sha512-FEQLazq9ecqLN5T6wWq26hCZf7kPqUbFC9vsHNbXMJtSZZWAcbJspT+/NEAQkBfFReZ8r9QlA9JHaAuo28MTJA==",
                        crossOrigin: "anonymous",
                        referrerPolicy: "no-referrer"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(layouts_Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: "font-roboto text-gray-800 ",
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(layouts_Footer, {})
        ]
    });
};

;// CONCATENATED MODULE: ./pages/_app.tsx




function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout, {
        title: pageProps.title ? pageProps.title : "Idle Courier",
        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 14:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 20:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 52:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 422:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664], () => (__webpack_exec__(824)));
module.exports = __webpack_exports__;

})();