"use strict";
(() => {
var exports = {};
exports.id = 784;
exports.ids = [784];
exports.modules = {

/***/ 320:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_network),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: ./data/branch.international.data.ts
const internationalBranchInfo = [
    {
        country: "India",
        name: "indian courior service pvt ltd",
        telephone: "98075555, 265264646",
        address: "Budget House, Daya Complex ,Budget House, Daya Complex, Budget House, Daya Complex",
        mail: "support@budget1.net",
        fax: "8955, 454",
        website: "www.idealcourier.com.np"
    },
    {
        country: "Singapore",
        name: "singpour courior service pvt ltd",
        telephone: "98075555, 265264646",
        address: "9 Airline Rd, Singapore 819827",
        mail: "info@idealcourier.com.np",
        fax: "8955, 819827",
        website: "www.idealcourier.com.np"
    },
    {
        country: "Middle East",
        name: "middle east courier pvt ltd",
        telephone: "+971 4 253 0300",
        address: "Warehouse No1, 21a St, Salahuddin Rd Al Khabisi Area,Deira, Behind RAK Ceramics - Dubai - United Arab Emirates",
        mail: "info@idealcourier.com.np",
        fax: "8955, 819827",
        website: "www.idealcourier.com.np"
    },
    {
        country: "USA/Canada",
        name: "Ship Global",
        telephone: "212 382 1741, 905 205 0897",
        address: "42W 38TH STREET, STE. 7051, MISSASSAUGA ON L4T 0A1, NEW YORK, NY 10018.",
        mail: "sales@shipglobal.us",
        fax: "8955, 819827",
        website: "www.idealcourier.com.np"
    },
    {
        country: "Honk Kong",
        name: "Far Dar Express Worldwide (HK) Ltd",
        telephone: "852 27826501, +852 27704576",
        telephoneExtension: "8001, 8007, 8005",
        address: "MISSASSAUGA ON L4T 0A1, 42W 38TH STREET, STE. 7051, NEW YORK, NY 10018",
        mail: "fardar@biznetvigator.com, hkgops@ayzexpress.com, fardar@biznetvigator.com, hkgops@ayzexpress.com",
        fax: "",
        website: "www.fardar.com"
    },
    {
        country: "United Kingdom",
        name: "United Business Xpress Ltd",
        telephone: "01753 762 860",
        telephoneExtension: "8001 8007 8005",
        address: " AIRHUB 1425 6,Poyle Trading Estate,Poyle Road,Colnbrook",
        mail: "",
        fax: "",
        website: ""
    }, 
];

;// CONCATENATED MODULE: ./pages/network.tsx




const network = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(Network, {});
};
/* harmony default export */ const pages_network = (network);
const Network = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "shadow-sm overflow-hidden min-h-[50vh] z-0 bg-center bg-cover",
                style: {
                    backgroundImage: "url(/wallpaper/walpaper.jpg)"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "text-white pt-48 pb-28 h-[10h] px-2 md:px-24 bg-black bg-opacity-60 w-full flex justify-center items-center ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "grid grid-cols-2 items-start w-full",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "justify-self-start",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/",
                                                children: "Home"
                                            })
                                        }),
                                        " ",
                                        ">",
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-orange-500",
                                            children: "Network"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-4xl font-bold",
                                    children: "Network Hub"
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Section1, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Section2, {})
        ]
    });
};
const Section1 = ()=>{
    const { 0: singleIntBranchData , 1: setSingleIntBranchData  } = (0,external_react_.useState)(internationalBranchInfo[0]);
    const selectSingleBranch = (current)=>{
        setSingleIntBranchData(current);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "my-10 py-10 font-work-sans",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container mx-auto px-20",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid grid-cols-12 gap-x-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-span-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "border px-10 py-5 bg-gray-900 text-white",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-xl font-bold font-work-sans my-2",
                                    children: "Our International branches"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    className: "pl-4 pr-16",
                                    children: internationalBranchInfo.map((current, index)=>{
                                        return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            onClick: ()=>selectSingleBranch(current)
                                            ,
                                            className: ' py-2 hover:text-orange-500 hover:bg-slate-900 hover:shadow-md cursor-pointer relative ani before:content-[""] before:hover:text-orange-500 before:hover:bg-orange-500 before:hover:animate-wiggle before:absolute before:w-[100%] before:h-[2px] before:bottom-0',
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "text-base font-bold font-work-sans",
                                                children: current.country
                                            })
                                        }, index);
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-span-8",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "border-2 bg-slate-100 shadow-lg pb-5 font-work-sans",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-2xl font-bold py-2 bg-gray-900 text-white",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "",
                                            children: singleIntBranchData.country
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "container mx-auto px-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-orange-600 py-2",
                                            children: "Idealcourier.com.np"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "grid grid-cols-2 pb-2 gap-x-2 gap-y-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/user.png",
                                                    type: "Name",
                                                    obj: singleIntBranchData.name
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/pin.png",
                                                    type: "Address",
                                                    obj: singleIntBranchData.address
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/call.png",
                                                    type: "Contact",
                                                    obj: singleIntBranchData.telephone
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/extension.png",
                                                    type: "Extension",
                                                    obj: singleIntBranchData.telephoneExtension
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/gmail.png",
                                                    type: "Mail",
                                                    obj: singleIntBranchData.mail
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/fax-machine.png",
                                                    type: "Fax",
                                                    obj: singleIntBranchData.fax
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/world-wide-web.png",
                                                    type: "Website",
                                                    obj: singleIntBranchData.website
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
const BranchCard = ({ obj , type , img  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "border-l-4 p-3 bg-gray-800 text-white border-l-orange-600 font-bold text-base font-work-sans gap-2 ",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-start flex-wrap gap-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: img,
                        className: "w-5 h-5",
                        alt: ""
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: " font-bold items-center text-base",
                        children: [
                            type,
                            ":"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "pl-6 text-justify pt-2 text-xs ",
                children: obj
            })
        ]
    });
};
const Section2 = ()=>{
    const { 0: singleIntBranchData , 1: setSingleIntBranchData  } = (0,external_react_.useState)(internationalBranchInfo[0]);
    const selectSingleBranch = (current)=>{
        setSingleIntBranchData(current);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "font-work-sans",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container mx-auto px-20",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid grid-cols-12 gap-x-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-span-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "border px-10 py-5 bg-gray-900 text-white",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-xl font-bold font-work-sans my-2",
                                    children: "Our Regional branches"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    className: "pl-4 pr-16",
                                    children: internationalBranchInfo.map((current, index)=>{
                                        return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            onClick: ()=>selectSingleBranch(current)
                                            ,
                                            className: ' py-2 hover:text-orange-500 hover:bg-slate-900 hover:shadow-md cursor-pointer relative ani before:content-[""] before:hover:text-orange-500 before:hover:bg-orange-500 before:hover:animate-wiggle before:absolute before:w-[100%] before:h-[2px] before:bottom-0',
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "text-base font-bold font-work-sans",
                                                children: current.country
                                            })
                                        }, index);
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-span-8",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "border-2 bg-slate-100 shadow-lg pb-5 font-work-sans",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-2xl font-bold py-5 bg-gray-900 text-white",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "",
                                            children: singleIntBranchData.country
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "container mx-auto px-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-orange-600 py-2",
                                            children: "Idealcourier.com.np"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "grid grid-cols-2 pb-2 gap-x-2 gap-y-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/user.png",
                                                    type: "Name",
                                                    obj: singleIntBranchData.name
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/pin.png",
                                                    type: "Address",
                                                    obj: singleIntBranchData.address
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/call.png",
                                                    type: "Contact",
                                                    obj: singleIntBranchData.telephone
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/extension.png",
                                                    type: "Extension",
                                                    obj: singleIntBranchData.telephoneExtension
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/gmail.png",
                                                    type: "Mail",
                                                    obj: singleIntBranchData.mail
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/fax-machine.png",
                                                    type: "Fax",
                                                    obj: singleIntBranchData.fax
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(BranchCard, {
                                                    img: "/icon/network/world-wide-web.png",
                                                    type: "Website",
                                                    obj: singleIntBranchData.website
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
const getServerSideProps = async (context)=>{
    return {
        props: {
            title: "Our Network | Ideal Courier"
        }
    };
};


/***/ }),

/***/ 796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 14:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 20:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 52:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 422:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664], () => (__webpack_exec__(320)));
module.exports = __webpack_exports__;

})();