"use strict";
(() => {
var exports = {};
exports.id = 753;
exports.ids = [753];
exports.modules = {

/***/ 212:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_contactus),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: ./data/faq.data.ts
const FaqData = [
    {
        title: "What is the procedure to send goods from nepal to usa",
        description: "Well you need to first contact office and visit office to fill form and details Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry  standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum"
    },
    {
        title: "What is the procedure to send goods from nepal to usa",
        description: "Well you need to first contact office and visit office to fill form and details Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry  standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum"
    },
    {
        title: "What is the procedure to send goods from nepal to usa",
        description: "Well you need to first contact office and visit office to fill form and details Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry  standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum"
    },
    {
        title: "What is the procedure to send goods from nepal to usa",
        description: "Well you need to first contact office and visit office to fill form and details Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry  standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum"
    },
    {
        title: "What is the procedure to send goods from nepal to usa",
        description: "Well you need to first contact office and visit office to fill form and details Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry  standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum"
    },
    {
        title: "What is the procedure to send goods from nepal to usa",
        description: "Well you need to first contact office and visit office to fill form and details Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry  standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum"
    }, 
];

;// CONCATENATED MODULE: ./pages/contactus.tsx




const contactus = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(Contactus, {});
};
/* harmony default export */ const pages_contactus = (contactus);
const Contactus = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "shadow-sm overflow-hidden min-h-[50vh] z-0 bg-center bg-cover",
                style: {
                    backgroundImage: "url(/wallpaper/walpaper.jpg)"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "text-white pt-48 pb-28 h-[10h] px-2 md:px-24 bg-black bg-opacity-60 w-full flex justify-center items-center ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "grid grid-cols-2 items-start w-full",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "justify-self-start",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/",
                                                children: "Home"
                                            })
                                        }),
                                        " | ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-orange-500",
                                            children: "contactus"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-4xl font-bold",
                                    children: "Contact us"
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mx-auto px-8",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-center mx-auto w-[45%] pt-6",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "text-center ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-orange-500 text-lg font-bold",
                                    children: "Get in touch"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: 'text-3xl before:contents[""] font-bold relative before:absolute before:h-1 before:w-1/3 pb-5 before:bottom-0 before: before:bg-orange-600',
                                    children: "Contact us"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-center text-gray-500 text-base mt-8",
                                    children: "We understand the importance of approaching each work integrally and believe in the power of simple and easy communication."
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[60%] mt-5 mx-auto",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("form", {
                            action: "",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid grid-cols-12 gap-5",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-span-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "text",
                                            placeholder: "Name",
                                            className: "w-full focus:outline-none focus:border py-3 border border-slate-300 px-3 focus:border-orange-500 focus:rounded-sm",
                                            title: "input"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-span-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "text",
                                            placeholder: "email",
                                            className: "w-full focus:outline-none focus:border py-3 border border-slate-300 px-3 focus:border-orange-500 focus:rounded-sm",
                                            title: "input"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-span-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "text",
                                            placeholder: "phone",
                                            className: "w-full focus:outline-none focus:border py-3 border border-slate-300 px-3 focus:border-orange-500 focus:rounded-sm",
                                            title: "input"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-span-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "text",
                                            placeholder: "company",
                                            className: "w-full focus:outline-none focus:border py-3 border border-slate-300 px-3 focus:border-orange-500 focus:rounded-sm",
                                            title: "input"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-span-12",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                            placeholder: "Enter you message",
                                            className: "w-full focus:outline-none focus:border py-2 pb-3 border border-slate-300 px-3 focus:border-orange-500 focus:rounded-sm",
                                            title: "input"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-span-12 mx-auto",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "bg-gray-800 rounded-sm hover:bg-orange-600 px-16 text-white py-3 ",
                                            children: "submit"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(SectionFAQ, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(ContactCard, {})
        ]
    });
};
const SectionFAQ = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "font-roboto-condensed mt-10 py-10 bg-slate-200",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container mx-auto px-5",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shadow-lg p-5 w-full bg-white",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-4xl text-center my-2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-bold ",
                            children: "FAQ"
                        })
                    }),
                    FaqData.map((current, index)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx(FAQCard, {
                            index: index,
                            data: current
                        }, index);
                    })
                ]
            })
        })
    });
};
const FAQCard = ({ data , index  })=>{
    const { 0: show , 1: setShow  } = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "border rounded-sm px-5 pb-4 cursor-pointer ",
        onClick: ()=>setShow(!show)
        ,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between my-2 ",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "text-orange-500 text-base font-bold",
                        children: [
                            index + 1,
                            ". ",
                            data.title
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: `bg-orange-500 px-2 text-white cursor-pointer text-lg`,
                        children: show ? "-" : "+"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${show ? "block" : "hidden"} animate-dropdown `,
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "text-sm text-gray-500 ",
                    children: data.description
                })
            })
        ]
    });
};
const ContactCard = ()=>{
    const cardDate = [
        {
            image: "icon/contactus/location.png",
            title: "ADDRESS",
            description: "Head Office: Gaushala Chowk, Battisputali Road (Along with NIC Asia Bank & Nearby Hotel Dwarika), Kathmandu, Nepal"
        },
        {
            image: "icon/contactus/smartphone.png",
            title: "PHONE",
            description: "+977-1-4578809, 4478678"
        },
        {
            image: "icon/contactus/email.png",
            title: "EMAIL",
            description: "+977-1-4578809, 4478678"
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-orange-500 p-12",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-center text-3xl font-bold text-white ",
                children: "Head Office"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "grid grid-cols-3 gap-5 justify-items-center pt-12",
                children: cardDate.map((current, index)=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: " shadow-lg rounded-sm p-5 w-96",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-center flex justify-center cursor-pointer",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        title: "image",
                                        src: current.image,
                                        className: " hover:scale-110 rounded-full h-20 w-20 p-2 bg-white text-black"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text-center text-white ",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "text-xl font-bold py-2",
                                            children: current.title
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-base text-gray-100",
                                            children: current.description
                                        })
                                    ]
                                })
                            ]
                        })
                    }, index);
                })
            })
        ]
    });
};
const getServerSideProps = async (context)=>{
    return {
        props: {
            title: "Contactus Page | Ideal Courier"
        }
    };
};


/***/ }),

/***/ 796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 14:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 20:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 52:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 422:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664], () => (__webpack_exec__(212)));
module.exports = __webpack_exports__;

})();