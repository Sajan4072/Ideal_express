"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 666:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: ./utils/custom-hooks/useFocus.ts

function useFocus() {
    const inputRef = (0,external_react_.useRef)(null);
    const setInputRef = ()=>{
        inputRef.current && inputRef.current.scrollIntoView();
    };
    return [
        inputRef,
        setInputRef
    ];
};

;// CONCATENATED MODULE: ./pages/index.tsx



const Home = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(HomePage, {});
};
/* harmony default export */ const pages = (Home);
const HomePage = ()=>{
    const { 0: showModal , 1: setShowModal  } = (0,external_react_.useState)(false);
    const [quote, showQuote] = useFocus();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Section1, {
                showQuote: showQuote,
                setShowModal: setShowModal
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Section2, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Section3, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(RequestQuote, {
                quote: quote
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Section4, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal, {
                showModal: showModal,
                setShowModal: setShowModal
            })
        ]
    });
};
const Section1 = ({ setShowModal , showQuote  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "shadow-sm overflow-hidden min-h-[100vh] z-0 bg-center bg-cover",
            style: {
                backgroundImage: "url(/wallpaper/walpaper.jpg)"
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-white pt-28 h-[10h] px-2 md:px-24 bg-black bg-opacity-80 w-full flex justify-center items-center ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full text-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "md:text-3xl text-3xl my-8 font-bold",
                            children: "Discover a better Logistic service with IDEAL EXPRESS"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-2xl mb-4",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Track your goods"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            onClick: ()=>{
                                showQuote();
                            },
                            className: "flex justify-center pb-8 items-center flex-wrap",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cursor-pointer py-8 px-3 md:w-40 w-32 bg-white flex flex-col items-center text-center text-black",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/icon/motorbike.png",
                                            className: "w-8 h-18",
                                            alt: "location"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "mt-2",
                                            children: "Quote"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cursor-pointer py-10 px-5 flex flex-col items-center w-30 md:w-40 bg-orange-500 text-black",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/icon/delivery.png",
                                            className: " w-8 h-18",
                                            alt: "location"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "mt-2 text-white",
                                            children: "Track"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cursor-pointer py-8 px-3 md:w-40 w-32 bg-white flex flex-col items-center text-center text-black",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/icon/location.png",
                                            className: " w-8 h-18",
                                            alt: "location"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "mt-2",
                                            children: "Location"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "w-full ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    title: "input",
                                    type: "text",
                                    placeholder: "Ex 1234565",
                                    className: "rounded-l-sm text-gray-500 font-sm focus:outline-none px-3 py-4 w-[70%] md:w-1/3 "
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                    onClick: ()=>setShowModal(true)
                                    ,
                                    className: "px-4 py-4 bg-orange-500 text-white rounded-r-sm font-bold",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fi fi-rr-search text-sm mr-1"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Track"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "hidden md:grid grid-cols-3 md:grid-cols-7 mt-10 items-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "p-3 bg-white rounded-sm cursor-pointer text-black font-semibold",
                                children: "our service"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "hidden md:grid grid-cols-4 gap-x-1 mt-10 items-end",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "h-44 cursor-pointer flex items-center justify-center bg-orange-700 ",
                                    children: "our service"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "h-40 cursor-pointer flex items-center justify-center bg-black bg-opacity-30 ",
                                    children: "our service"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "h-40 cursor-pointer flex items-center justify-center bg-black bg-opacity-30 ",
                                    children: "our service"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "h-40 cursor-pointer flex items-center justify-center bg-black bg-opacity-30 ",
                                    children: "our service"
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
const Section2 = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-white container",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "my-10 md:mx-16 mx-3",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: " text-left grid grid-cols-12",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "md:col-span-5 col-span-12",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-orange-500 font-roboto mb-3 font-bold col-span-3",
                                children: "Your Package, Your Rules"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-2xl font-bold font-work-sans",
                                children: "We Continue To Pursue That Same Vision In Today' Complex, Uncertain World, Working Every Day"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "grid md:grid-cols-4 grid-cols-2 md:gap-3 gap-2 mt-10",
                    children: [
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ].map((data, index)=>{
                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "border p-3 rounded-md cursor-pointer group hover:border-orange-500",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/icon/credit-card.png",
                                        className: "w-10 group-hover:animate-bounce h-18",
                                        alt: ""
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "group-hover:text-orange-500 text-gray-800 text-lg font-roboto mb-2 mt-3 font-bold col-span-3",
                                        children: "Transparent Price"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-base text-gray-400 ",
                                        children: "The world of international supply chains involves a myriad of unknown risks and challenging regulations."
                                    })
                                })
                            ]
                        }, index);
                    })
                })
            ]
        })
    });
};
const Section3 = ()=>{
    const dataFor = [
        {
            icon: "",
            count: 445678,
            title: "SHIPMENTS COMPLETED"
        },
        {
            icon: "",
            count: 240,
            title: "DESTINATIONS"
        },
        {
            icon: "",
            count: 45,
            title: "LOCAL PARTNERS"
        },
        {
            icon: "",
            count: 7,
            title: "YEARS OF EXPERIENCE"
        }
    ];
    const { 0: data , 1: setData  } = (0,external_react_.useState)(dataFor);
    const handleFocus = ()=>{};
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        onFocus: handleFocus,
        className: "bg-center bg-cover bg-fixed relative",
        style: {
            backgroundImage: 'url("/bg/bgsection3.jpg")'
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "pt-16 bg-black bg-opacity-50",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mx-auto px-5 text-white ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mt-5 w-1/2 relative",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: " before:w-[5.8rem] before:-left-2 before:-bottom-2 before:-top-2 before:-right-12 before:hover:animate-none before:absolute before:animate-pulse2 before:rounded-full before:border-2 before:border-orange-600 cursor-pointer p-1 w-[13%] rounded-full border-2 relative border-orange-600",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: " rounded-full px-[1.55rem] py-4 text-white bg-orange-600 text-2xl fa fa-play",
                                "aria-hidden": "true"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid grid-cols-2 py-10",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-base font-work-sans",
                                        children: "Your Package, Your Rules"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-4xl font-bold mt-5 font-work-sans",
                                        children: "Digital Freight That Saves Your Time!"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "grid grid-cols-2 gap-y-8 gap-x-5",
                                    children: data.map((current, index)=>{
                                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "justify-self-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex justify-center",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: "/icon/global64px.png",
                                                        alt: ""
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex mt-2 items-center flex-col gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                            className: "text-3xl font-bold",
                                                            children: [
                                                                current.count,
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "pl-1",
                                                                    children: "+"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "text-xl",
                                                            children: current.title
                                                        })
                                                    ]
                                                })
                                            ]
                                        }, index);
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
const Modal = ({ showModal , setShowModal  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `${showModal ? "fixed" : "hidden"} animate-modal font-poppin inset-0 bg-black bg-opacity-90 min-h-[80vh]  z-50`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex justify-center h-[100vh] items-center",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "border w-2/3 border-white p-6 text-white relative",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        onClick: ()=>setShowModal(false)
                        ,
                        className: "text-white fa fa-times absolute -right-2 text-2xl cursor-pointer -top-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex justify-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-white text-xl font-bold ",
                                children: "Ideal Tracking"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 text-white text-base px-8 py-2 rounded-md bg-gray-900 font-bold ",
                                children: "Print"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "bg-orange-600 rounded-md my-4 p-2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-white text-base font-bold text-center",
                            children: "Shipment Status"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "my-3",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "border-transparent border-b text-base font-bold text-white pb-2",
                            children: "Shipping Information"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: " bg-gray-900 p-3 rounded-md",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid grid-cols-12 gap-4",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-span-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm font-bold mr-2",
                                                children: "Origin:"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm",
                                                children: "afdas"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-span-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm font-bold mr-2",
                                                children: "Package:"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm",
                                                children: "afdas"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-span-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm font-bold mr-2",
                                                children: "Destination:"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm",
                                                children: "afdas"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-span-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm font-bold mr-2",
                                                children: "Type of Shipment:"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm",
                                                children: "afdas"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-span-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm font-bold mr-2",
                                                children: "Weight:"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm",
                                                children: "afdas"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-span-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm font-bold mr-2",
                                                children: "Shipment Mode:"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm",
                                                children: "afdas"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-span-12",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm font-bold mr-2",
                                                children: "Carrier Reference No:"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-sm",
                                                children: "afdas"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "my-3",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "border-transparent border-b text-base font-bold text-white pb-2",
                            children: "Shipping History"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                        className: "table-auto w-full rounded-md bg-gray-900",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                    className: "bg-green-700 text-center text-base",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                            className: "",
                                            children: "Sn"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                            className: "",
                                            children: "TLD"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                            className: "",
                                            children: "Duration"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                            className: "",
                                            children: "Registration"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                            className: "",
                                            children: "Renewal"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                            className: "",
                                            children: "Transfer"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                            className: "",
                                            children: "Register"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                    className: "text-center text-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                            children: "1"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                            children: "asfd"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                            children: "asfd"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                            children: "asfd"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                            children: "asfd"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                            children: "asfd"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                            children: "asfd"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
const RequestQuote = ({ quote  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-slate-100 relative ",
        ref: quote,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container mx-auto px-10 pb-5",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex -mt-[3.5rem] absolute z-10",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "py-4 px-6 font-sm font-bold text-white bg-orange-500",
                            children: "Request A Quote"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "py-4 px-6 bg-black bg-opacity-30 font-bold text-white",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-white",
                                children: "Track and Trace"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "bg-white px-12 py-3",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid grid-cols-12 gap-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-span-8",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-base font-bold",
                                                children: "Personal data"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "grid grid-cols-3 gap-3 pt-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            title: "name",
                                                            type: "text",
                                                            placeholder: "Name",
                                                            className: "placeholder:text-gray-400 px-3 py-2 w-full focus:outline-none hover:border-orange-600 border border-gray-300"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            title: "name",
                                                            type: "text",
                                                            placeholder: "Email",
                                                            className: "placeholder:text-gray-400 px-3 py-2 w-full focus:outline-none hover:border-orange-600 border border-gray-300"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            title: "name",
                                                            type: "text",
                                                            placeholder: "Phone",
                                                            className: "placeholder:text-gray-400 px-3 py-2 w-full focus:outline-none hover:border-orange-600 border border-gray-300"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "pt-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-base font-bold",
                                                children: "Personal data"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "grid grid-cols-3 gap-3 pt-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            title: "name",
                                                            type: "text",
                                                            className: "px-3 py-2 rounded-sm w-full focus:outline-none hover:border-orange-600 border border-gray-300"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            title: "name",
                                                            type: "text",
                                                            className: "px-3 py-2 rounded-sm w-full focus:outline-none hover:border-orange-600 border border-gray-300"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            title: "name",
                                                            type: "text",
                                                            className: "px-3 py-2 rounded-sm w-full focus:outline-none hover:border-orange-600 border border-gray-300"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "pt-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            className: "w-full text-white bg-black hover:bg-gray-900 p-3",
                                            children: "Request A quote"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-span-4 bg-orange-500 mx-5",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text-center py-2 text-white px-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-2xl font-bold my-3",
                                            children: "How can we help you"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "mb-3 font-xs",
                                            children: "We Understand the importance approaching each work integrally and believe in the power of simple and easy communication "
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "px-3 py-2 rounde-sm text-center bg-black text-white",
                                            children: "contact us"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};
const Section4 = ()=>{
    const data = [
        {
            icon: "box.png",
            title: "PICKUP AND PACKING",
            description: "Our Packing and pickup facilities allows customers hassle free shipment solutions"
        },
        {
            icon: "best-price.png",
            title: "AFFORDABLE PRICE",
            description: "We provide cheapest price ever for international and national courier both"
        },
        {
            icon: "order-tracking.png",
            title: "TRACKING SERVICE",
            description: "We provide you instant updates of the progress of the transportation of goods."
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-orange-600",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container text-white mx-auto p-10 ",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-cols-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-2xl font-bold",
                                children: "WHAT MAKES US SPECIAL"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "px-5 text-justify",
                                children: "We are ready to give solutions tailored to the customer needs and requirements. To confirm elevated precision in our services, we have developed a complete infrastructure required to handle both national and international delivery of shipments. ."
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "grid grid-cols-3 my-8 gap-8",
                    children: data.map((current, index)=>{
                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: " shadow-2xl bg-[#c94400] px-3 py-8 rounded-sm",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "grid justify-center my-2",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        alt: "packaging",
                                        src: `/icon/offer/${current.icon}`,
                                        className: "w-100"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            className: "text-2xl mb-2",
                                            children: current.title
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: current.description
                                        })
                                    ]
                                })
                            ]
                        }, index);
                    })
                })
            ]
        })
    });
};
const getServerSideProps = async (context)=>{
    return {
        props: {
            title: "Home Page | Ideal Courier"
        }
    };
};


/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(666));
module.exports = __webpack_exports__;

})();