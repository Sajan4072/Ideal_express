import React from 'react'

const test = () => {
    return (
        <div className='min-h-screen'>test</div>
    )
}

export default test